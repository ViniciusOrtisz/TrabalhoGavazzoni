package br.unipar.programacaointernet.servicecep.vendaapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendaApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(VendaApiApplication.class, args);
    }

}
