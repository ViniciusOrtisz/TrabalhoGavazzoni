package controller;

public class VendaApiController {
}
