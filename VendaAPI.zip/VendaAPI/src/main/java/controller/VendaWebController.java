package controller;

public class VendaWebController {
}
