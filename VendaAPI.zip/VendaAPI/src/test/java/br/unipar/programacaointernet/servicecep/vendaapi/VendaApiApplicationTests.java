package br.unipar.programacaointernet.servicecep.vendaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendaApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
