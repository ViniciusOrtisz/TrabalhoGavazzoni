/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Vendas;


public class VendasDAO extends GenericDAO<Vendas> {

    @Override
    protected Vendas construirObjeto(ResultSet rs) {
        Vendas vendas = null;
            
        vendas = new Vendas();
        try {
            vendas.setQuantidade(rs.getInt("QUANTIDADE"));
            vendas.setValor(rs.getDouble("VALOR_UN"));
            vendas.setObservações(rs.getString("OBSERVACAO"));
        } catch (SQLException ex) {
            Logger.getLogger(VendasDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       return vendas;
    }

    @Override
    public boolean salvar(Vendas obj) {
        
        String sql = "INSERT INTO public.vendas(\""+
                "QUANTIDADE\",\"VALOR_UN\", \"OBSERVACAO\")VALUES (?, ?, ?);";
        
        PreparedStatement ps = null;
        
        
        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(2, obj.getQuantidade());
            ps.setDouble(3, obj.getValor());
            ps.setString(4,obj.getObservações());
            ps.executeUpdate();
            ps.close();
            
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(VendasDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean atualizar(Vendas obj) {
        
        String sql = "UPDATE public.vendas SET \"QUANTIDADE\" = ?, \"VALOR_UN\" = ?, \"OBSERVACAO\" = ? WHERE \"ID\" = ?";
        
        PreparedStatement ps = null;
        
        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(3, obj.getRaAluno());
            ps.setInt(1, obj.getQuantidade());
            ps.setDouble(2,obj.getValor());
            ps.setString(4,obj.getObservações());
            ps.executeUpdate();
            ps.close();
            
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(VendasDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
        
    }
    
   
    
}
